package com.infosys.anz.controller;


import java.text.ParseException;
import java.util.Date;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.anz.model.TransactionList;
import com.infosys.anz.model.UserAccounts;


/***
 * 
 * @author RufeeyaTarannum
 * 
 * Test Data to test the controllers
 *
 */

@RestController
public class ControllersTestData {

	@RequestMapping(value = "/accounts", method = RequestMethod.GET)
	public UserAccounts getAccounts() {
		
		UserAccounts account = new UserAccounts();
		
		account.setAccountNumber(123456789);
		account.setAccountName("dummy");
		account.setAccountType("dummy");
		account.setBalanceDate(new Date());
		account.setCurrency("dummy");
		account.setOpeningBalance(2000);

		return account;
	}
	
	@RequestMapping(value = "/transactions", method = RequestMethod.GET)
	public TransactionList getTransactions() throws ParseException {

		TransactionList list = new TransactionList();
		
		list.setAccountNumber(123456789);
		list.setAccountName("dummy");
		list.setCurrency("dummy");
		list.setActionType("dummy");
		list.setNarrative("dummy");

		return list;
	}

}