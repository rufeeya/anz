package com.infosys.com.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotSame;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.infosys.anz.entity.TransactionListEntity;
import com.infosys.anz.model.TransactionList;
import com.infosys.anz.repository.TransactionListRepository;
import com.infosys.anz.service.TransactionListService;

/**
 * 
 * @author RufeeyaTarannum
 * 
 * ServiceTest - takes care of testing service as well as  repository
 *
 */

@RunWith(MockitoJUnitRunner.class)

public class TransactionListServiceTest {
	
	@InjectMocks
	private TransactionListService transactionListService;
	
	@Mock
	private TransactionListRepository transactionListRepository;
	
	
	TransactionListEntity transactionListEntity1 = new TransactionListEntity();
	TransactionListEntity transactionListEntity2 = new TransactionListEntity();
	
	List<TransactionListEntity> actual = new ArrayList<TransactionListEntity>();
	
	@Before
	public void initialWork() {
		
		/* Initializations to test getAccounts() */
		
		transactionListEntity1.setAccountNumber(585309209);
		transactionListEntity1.setAccountName("SGSavings726");
		transactionListEntity1.setCurrency("SGD");
		transactionListEntity1.setValueDate(new Date());
		transactionListEntity1.setCreditAmount((float)9327.51);
		transactionListEntity1.setDebitAmount(0);
		transactionListEntity1.setActionType("Credit");
		transactionListEntity1.setNarrative(" ");
		
		transactionListEntity2.setAccountNumber(123456789);
		transactionListEntity2.setAccountName("dummy");
		transactionListEntity2.setCurrency("dummy");
		transactionListEntity2.setValueDate(new Date());
		transactionListEntity2.setCreditAmount(0);
		transactionListEntity2.setDebitAmount((float)500.51);
		transactionListEntity2.setActionType("Debit");
		transactionListEntity2.setNarrative(" ");
		
		actual.add(transactionListEntity1);
		actual.add(transactionListEntity2);
	}
	
	@Test
	public void testGetTransactionPositive() {
		
		when(transactionListRepository.getTransactions(585309209)).thenReturn(actual);
		
		List<TransactionList> expected = transactionListService.displayTransactions(585309209);
		
		assertEquals(2,expected.size());
		
		verify(transactionListRepository, times(1)).getTransactions(585309209);
			
	}
	
	@Test
	public void testGetTransactionNegative() {
		
		when(transactionListRepository.getTransactions(585309209)).thenReturn(actual);
		
		List<TransactionList> expected = transactionListService.displayTransactions(000000000);
		
		System.out.println(expected.size());
		
		assertNotEquals(2,expected.size());
		
		assertNotSame(transactionListRepository.getTransactions(585309209),expected);
			
	}
		
}
