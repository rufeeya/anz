package com.infosys.anz.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.infosys.anz.model.TransactionList;
import com.infosys.anz.service.TransactionListService;

/**
 * 
 * @author RufeeyaTarannum
 * 
 * Controller handle that invokes service method to get list of transaction for the selected account
 * 
 * Gets account number as request parameter to display transaction
 * 
 * Gets userId as request parameter for displaying accounts when "back" is pressed
 *
 */

@RestController
public class TransactionListsController {
	
	@Autowired
	TransactionListService transactionListService;

	
	private String command = "command";
	private String displayTransactions = "displayTransactions";
	
	@GetMapping(value = "/showTransactions")
	public ModelAndView showAccounts(Model model, @RequestParam("accountNumber") Integer accountNumber, @RequestParam("userId") Integer userId,
			TransactionList transactionList, BindingResult bindingResult) {
		
		ModelAndView modelAndView = null;
		
		if (bindingResult.hasErrors()) {
			modelAndView = new ModelAndView(displayTransactions, command, transactionList);

		} else {
			
			List<TransactionList> transactions = transactionListService.displayTransactions(accountNumber);
			model.addAttribute("transactions", transactions);
			model.addAttribute("userId", userId);
			
			modelAndView = new ModelAndView(displayTransactions, command, transactionList);
		}
		
		return modelAndView;
		
	}
	

}
