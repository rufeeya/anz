package com.infosys.anz.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/***
 * 
 * @author RufeeyaTarannum
 * 
 * TransactionListEntity which represents the transaction_List_Entity table in the database
 *
 */

@Entity
@Table(name = "transaction_List_Entity")

public class TransactionListEntity {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer tid;
	
	private Integer accountNumber;
    private String accountName;
    private Date valueDate;
    private String currency;
    private float debitAmount;
    private float creditAmount;
    private String actionType;
    private String narrative;
    
    public Integer getAccountNumber() {
        return accountNumber;
    }
    public void setAccountNumber(Integer accountNumber) {
        this.accountNumber = accountNumber;
    }
    
    public String getAccountName() {
        return accountName;
    }
    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }
    public Date getValueDate() {
        return valueDate;
    }
    public void setValueDate(Date valueDate) {
        this.valueDate = valueDate;
    }
    public String getCurrency() {
        return currency;
    }
    public void setCurrency(String currency) {
        this.currency = currency;
    }
    public float getDebitAmount() {
        return debitAmount;
    }
    public void setDebitAmount(float debitAmount) {
        this.debitAmount = debitAmount;
    }
    public float getCreditAmount() {
        return creditAmount;
    }
    public void setCreditAmount(float creditAmount) {
        this.creditAmount = creditAmount;
    }
    public String getActionType() {
        return actionType;
    }
    public void setActionType(String actionType) {
        this.actionType = actionType;
    }
    public String getNarrative() {
        return narrative;
    }
    public void setNarrative(String narrative) {
        this.narrative = narrative;
    }

}
