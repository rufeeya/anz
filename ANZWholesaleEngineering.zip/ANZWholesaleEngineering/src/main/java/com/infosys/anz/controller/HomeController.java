package com.infosys.anz.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

@RestController

@SessionAttributes("contextPath")

public class HomeController {
	
	@GetMapping("/")
	public ModelAndView getHome(HttpSession session, HttpServletRequest request, SessionStatus sessionStatus) {
		session.setAttribute("contextPath", request.getContextPath());

		return new ModelAndView("home", "", "");
	}
	
	@GetMapping("/home")
	public ModelAndView getHomeDetails(HttpSession session, HttpServletRequest request, SessionStatus sessionStatus) {
		session.setAttribute("contextPath", request.getContextPath());

		return new ModelAndView("home", "", "");
	}

}
