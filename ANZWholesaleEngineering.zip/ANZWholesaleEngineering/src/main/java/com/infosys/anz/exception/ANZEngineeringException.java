package com.infosys.anz.exception;

@SuppressWarnings("serial")

public class ANZEngineeringException extends Exception{
	
	public ANZEngineeringException(String message) {
		super(message);
	}

}
