package com.infosys.anz.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.infosys.anz.entity.TransactionListEntity;
import com.infosys.anz.model.TransactionList;
import com.infosys.anz.repository.TransactionListRepository;

/****
 * 
 * @author RufeeyaTarannum
 * 
 * Service layer for displaying list of transaction for the selected account
 *
 */

@Service
public class TransactionListService {
	
	@Autowired
	TransactionListRepository transactionListRepository;
	
	public List<TransactionList> displayTransactions(Integer accountNumber) {
		
		List<TransactionListEntity> transactionListEntity = transactionListRepository.getTransactions(accountNumber);
		
		List<TransactionList> transactionList = new ArrayList<>();
		
		for(TransactionListEntity t :transactionListEntity) {
			
			TransactionList transaction = new TransactionList();
		
			transaction.setAccountName(t.getAccountName());
			transaction.setAccountNumber(t.getAccountNumber());
			transaction.setValueDate(t.getValueDate());
			transaction.setCurrency(t.getCurrency());
			transaction.setDebitAmount(t.getDebitAmount());
			transaction.setCreditAmount(t.getCreditAmount());
			transaction.setActionType(t.getActionType());
			transaction.setNarrative(t.getNarrative());
			
			transactionList.add(transaction);
		}

		return transactionList;
	}

}
