package com.infosys.anz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/*****
 * 
 * @author RufeeyaTarannum
 * 
 * Main class where the Application flow starts
 *
 */

@SpringBootApplication

@ComponentScan(basePackages = {"com.infosys.anz.controller","com.infosys.anz.entity","com.infosys.anz.repository","com.infosys.anz.service"})

public class AnzWholesaleEngineeringApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnzWholesaleEngineeringApplication.class, args);
	}

}
