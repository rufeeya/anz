package com.infosys.anz.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/***
 * 
 * @author RufeeyaTarannum
 * 
 * UserAccountsEntity which represents the User_Accounts_Entity table in the database
 *
 */

@Entity
@Table(name = "User_Accounts_Entity")

public class UserAccountsEntity {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer accountNumber;
	
    private String accountName;
    private String accountType;
    private Date balanceDate;
    private String currency;
    private float openingBalance;
    
    private Integer userId;
    
    public Integer getAccountNumber() {
        return accountNumber;
    }
    public void setAccountNumber(Integer accountNumber) {
        this.accountNumber = accountNumber;
    }
    public String getAccountName() {
        return accountName;
    }
    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }
    public String getAccountType() {
        return accountType;
    }
    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }
    public Date getBalanceDate() {
        return balanceDate;
    }
    public void setBalanceDate(Date balanceDate) {
        this.balanceDate = balanceDate;
    }
    public String getCurrency() {
        return currency;
    }
    public void setCurrency(String currency) {
        this.currency = currency;
    }
    public float getOpeningBalance() {
        return openingBalance;
    }
    public void setOpeningBalance(float openingBalance) {
        this.openingBalance = openingBalance;
    }
    public Integer getUserId() {
		return userId;
    }
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

}
